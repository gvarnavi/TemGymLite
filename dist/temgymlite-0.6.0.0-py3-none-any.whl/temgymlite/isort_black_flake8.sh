#!/bin/bash

for f in [^_]*.py
do
	#echo $f
	isort --profile black $f
	black $f
	flake8 --max-line-length 200 --ignore=E121,E123,E126,E226,E24,E704,W503,W504,E203,E266 $f
done
